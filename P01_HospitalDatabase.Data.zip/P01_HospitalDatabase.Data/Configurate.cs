﻿namespace P01_HospitalDatabase.Data
{
    public class Configurate
    {
        public const string ConnectionString = @"Server=DESKTOP-CP2NEHV\SQLEXPRESS;Database=Hospital;Integrated Security=True;";
    }
}